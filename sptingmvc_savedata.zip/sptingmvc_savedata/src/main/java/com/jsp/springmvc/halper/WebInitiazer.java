package com.jsp.springmvc.halper;


import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;




public class WebInitiazer extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		Class[] c = {ConfigrationClass.class};
		return c;
	
	}

	@Override
	protected String[] getServletMappings() {
		String[] url = {"/"};
		return url;
	}
	

}
