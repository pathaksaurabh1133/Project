package com.jsp.springmvc.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;

import com.jsp.springmvc.entity.Hospital;

public class HospitalDriver {
	@Autowired
	EntityManagerFactory emf;
	
	public void save(Hospital h)
	{
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(h);
		et.commit();
	}

}
