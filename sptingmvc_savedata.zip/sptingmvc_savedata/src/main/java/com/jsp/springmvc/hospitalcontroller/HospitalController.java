package com.jsp.springmvc.hospitalcontroller;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jsp.springmvc.controller.HospitalDriver;
import com.jsp.springmvc.entity.Hospital;

@Controller
public class HospitalController {
	@Autowired
	HospitalDriver hd;
	@RequestMapping("/save")
	public String m1(ServletRequest req)
	{
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String address = req.getParameter("address");
		
		Hospital h = new Hospital();
		
		h.setId(Integer.parseInt(id));
		h.setName(name);
		h.setAddress(address);
		
		hd.save(h);
		
		return "HopitalForm";
	}

}
