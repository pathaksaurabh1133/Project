package com.jsp.applicationcontext1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PenDriver {
	public static void main(String[] args) {
		ApplicationContext ac = new AnnotationConfigApplicationContext(ConfigClass.class);
		
		Pen p = (Pen) ac.getBean("pen"); //class name is consider as bean id and first latter consider as lower case
		
		p.write();
		
		
	}

}
