package com.jsp.applicationcontext1;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = {" com"})
// it is used to specify the package name to ioc container.
//it is used to specify the location of pojo class to the ioc container.
public class ConfigClass {

}
