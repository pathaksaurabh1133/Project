package com.jsp.applicationcontext1;

import org.springframework.stereotype.Component;

@Component   //@component annotation is used to make a class as component class
			// @component is used to specify a pojo class to application context Ioc container
			//Application context creates objects for the classes witch are annotated with @comopnent annation
public class Pen {
	
	Pen()
	{
		System.out.println("constructor is invoked");
	}
	 
	public void write()
	{
		System.out.println("method is invoked");
	}
}
