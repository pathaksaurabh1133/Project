package com.jsp.beandefinition;

public class B {
	public void work() {
		System.out.println("working");
	}

}
