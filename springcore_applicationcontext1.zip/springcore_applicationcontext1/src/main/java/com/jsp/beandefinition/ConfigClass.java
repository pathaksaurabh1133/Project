package com.jsp.beandefinition;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = "com.jsp.beandefinition")
@Configuration
public class ConfigClass {
	
	@Bean
	public B getB() {
		return new B();
	}

}
