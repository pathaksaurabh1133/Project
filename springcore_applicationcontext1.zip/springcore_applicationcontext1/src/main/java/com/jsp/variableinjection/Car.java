package com.jsp.variableinjection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Car {
	
	@Value("101")
	int id;
	
	@Value("suzuki")
	String brand;
	
	@Value("1500000.00")
	double price;
	
	
	@Autowired // @Autowired is used to achieve automatic dependency injection
	Engine engine;

}
