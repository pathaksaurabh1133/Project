package com.jsp.variableinjection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("savan")
public class Bike {
	@Value("101") //@value annotation is used to assign the value of pojo class properties
	int id;
	
	@Value("pulsar")
	String brand;
	
	@Value("100000.00")
	double price;

}
