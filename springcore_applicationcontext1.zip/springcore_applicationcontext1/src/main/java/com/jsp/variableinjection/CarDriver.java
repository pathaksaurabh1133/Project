package com.jsp.variableinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jsp.applicationcontext1.ConfigClass;

public class CarDriver {
	public static void main(String[] args) {
		ApplicationContext ac = new AnnotationConfigApplicationContext(ConfigClass.class);
		
		Car c = (Car) ac.getBean("car");
		
		Engine e = c.engine;
		
		e.work();
		
	}

}
