package com.jsp.variableinjection;

import org.springframework.stereotype.Component;

@Component
public class Engine {
	
	public void work() {
		System.out.println("engine is working properly");
	}

}
