package com.jsp.variableinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jsp.applicationcontext1.ConfigClass;

public class BikeDriver {
	
	public static void main(String[] args) {
		ApplicationContext ac = new AnnotationConfigApplicationContext(ConfigClass.class);
		
		Bike b = (Bike) ac.getBean("savan");
		
		System.out.println(b.id);
		System.out.println(b.brand);
		System.out.println(b.price);
	}
}
