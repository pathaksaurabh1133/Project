 package com.jsp.primary;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ButterScotch implements IceCream {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
		System.out.println("baby is eating butterscotch");
		
	}

}
