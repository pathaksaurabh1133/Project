package com.jsp.primary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Baby {

	@Autowired
	//@Qualifier("butterScotch")
	IceCream iceCream;
	
	public void cry() {
		System.out.println("baby is crying");
		
		iceCream.eat();
		
		System.out.println("finished");
	}
	
}
