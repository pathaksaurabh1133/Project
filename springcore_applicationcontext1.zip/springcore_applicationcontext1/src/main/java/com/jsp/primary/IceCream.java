package com.jsp.primary;

public interface IceCream {
	void eat();

}
