package com.jsp.primary;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.jsp.primary")
public class ConfigClass {

}
