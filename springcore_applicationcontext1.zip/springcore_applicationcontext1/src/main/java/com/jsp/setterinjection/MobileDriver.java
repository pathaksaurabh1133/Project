package com.jsp.setterinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jsp.applicationcontext1.ConfigClass;

public class MobileDriver {
	
	public static void main(String[] args) {
		 ApplicationContext ac = new AnnotationConfigApplicationContext(ConfigClass.class);
		 
		 Mobile m = (Mobile) ac.getBean("mobile");
		 
		 System.out.println(m.getId());
		 System.out.println(m.getBrand());
		 System.out.println(m.getModel());
		 System.out.println(m.getPrice());
		 
		 Sim s = m.getSim();
		 
		 s.work();
	}

}
