package com.jsp.setterinjection;

import org.springframework.stereotype.Component;

@Component
public class Sim {
	
	public void work() {
		
		System.out.println("sim is working ");
		
	}

}
