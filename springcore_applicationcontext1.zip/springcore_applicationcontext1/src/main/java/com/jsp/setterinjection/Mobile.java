package com.jsp.setterinjection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class Mobile {
	
	private int id;
	private String brand;
	private String model;
	private double price;
	
	private Sim sim;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	@Value("111")
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	@Value("samsung")
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	@Value("s22 plus")
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	@Value("120000.0")
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the sim
	 */
	public Sim getSim() {
		return sim;
	}

	/**
	 * @param sim the sim to set
	 */
	@Autowired
	public void setSim(Sim sim) {
		this.sim = sim;
	}
	

}
