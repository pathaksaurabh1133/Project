package com.jsp.democontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.jsp.practice.Student;

@Controller
public class StudentController {
	
	@Autowired
	Student s;
	
	s.m1;

}
