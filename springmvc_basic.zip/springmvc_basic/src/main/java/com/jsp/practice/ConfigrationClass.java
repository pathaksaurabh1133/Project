package com.jsp.practice;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = "com.jsp.practice")
@Configuration
public class ConfigrationClass {

}
