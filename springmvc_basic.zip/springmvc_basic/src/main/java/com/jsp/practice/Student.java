package com.jsp.practice;

import org.springframework.stereotype.Component;

@Component
public class Student {
	
	public void m1()
	{
		System.out.println("hello");
	}

}
