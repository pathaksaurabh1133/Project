package com.jsp.mvcdemo.helper;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.jsp")
public class Configration {

}
